<!-- custom-create-your-own-tab-product -->
<?php
/**
 * Plugin Name:       custom-create-your-own-tab-product
 * Plugin URI:        https://cmsmart.net
 * Description:       custom-create-your-own-tab-product
 * Version:           1.1.0
 * Requires at least: 5.2
 * Requires PHP:      7.1
 * Author:            Ngọc Huy
 * Author URI:        https://cmsmart.net
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       custom-create-your-own-tab-product
 * Domain Path:       /languages
 */

add_action('nbd_js_config','creYourFt');
function creYourFt(){
    ?>
        var cryow_js = 1;
    <?php 
}

add_action( 'wp_enqueue_scripts','add_js_ct_tab_product',100);
function add_js_ct_tab_product() {
    wp_add_inline_script( 'nbdesigner', 'const cryow_js = true;', 'before' );
    wp_enqueue_style('custom-styledd', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css', array(), '1.0.0', 'all');
}

add_action('nbd_extra_css','style_ct_tab_product');
function style_ct_tab_product($path){
  ?>
        <link rel="stylesheet" href="<?= plugin_dir_url(__FILE__) . 'assets/style.css'; ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <?php
}

// add_filter('hvc_nbd_add_to_cart_redirect','nbdo_chvc_nbd_add_to_cart_redirect');
// function nbdo_chvc_nbd_add_to_cart_redirect($url){
//     if(isset($_COOKIE['redirect']) && $_COOKIE['redirect'] == 1){
//         unset($_COOKIE['redirect']); 
//         return $url;
//     }
//    return '';
// }

add_action('nbo_before_fields','nbo_before_fields_tab_product_ct');
function nbo_before_fields_tab_product_ct($product_id) {
    $product = wc_get_product($product_id);
    $product_description = get_post_field('post_content', $product_id);
    $rating_count = $product->get_rating_count();
    $review_count = $product->get_review_count();
    $average      = $product->get_average_rating();
    ?>
        <style type="text/css">
            .infoP {
                display: flex;
                gap: 6px;
                cursor: pointer;
                margin-bottom: 6px;
            }
            .infoP span {
                font-size: 13px;
                font-weight: 600;
                color: #1164a9;
            }
            .infoP span:hover {
                text-decoration: underline;
            }
            .ct_button_change {
                margin: 15px 0px;
                display: flex;
                align-items: center;
                width: 50%;
                cursor: pointer;
            }
        </style>
        <?php 
            if ( $rating_count > 0 ) : ?>

            <div class="woocommerce-product-ratingct">
                <?php echo wc_get_rating_html( $average, $rating_count ); ?>
                <?php if ( comments_open() ) : ?>
                    <?php //phpcs:disable ?>
                    <p class="ratingct__review">(<?php printf( _n( '%s customer review', '%s customer reviews', $review_count, 'woocommerce' ), '<span class="count">' . esc_html( $review_count ) . '</span>' ); ?>)</p>
                    <?php // phpcs:enable ?>
                <?php endif ?>
            </div>

            <?php endif; ?>
        <div class="infoP" ng-click="showPreview();">
            <svg width="15px" height="15px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M2 20V4C2 3.44772 2.44772 3 3 3H8.44792C8.79153 3 9.11108 3.17641 9.29416 3.46719L10.5947 5.53281C10.7778 5.82359 11.0974 6 11.441 6H21C21.5523 6 22 6.44772 22 7V20C22 20.5523 21.5523 21 21 21H3C2.44772 21 2 20.5523 2 20Z" stroke="#200E32" stroke-width="2"/>
                <path d="M12 13L12 17" stroke="#200E32" stroke-width="2" stroke-linecap="round"/>
                <circle cx="12" cy="10" r="1" fill="#200E32"/>
            </svg>
            <span><?php _e('Product Info, Reviews & Guidelines','web-to-print-online-designer'); ?></span>
        </div>
        <div class="ct-available">
            <p><?php _e('Available product customization based on your selling region and preferences, pricing & guidelines','web-to-print-online-designer'); ?></p>
        </div>
        <div ng-if="settings.nbdesigner_show_button_change_product == 'yes'" ng-click="showProducts()" class="ct_button_change menu-item nbd-change-product nbd-show-popup-products animated slideInDown animate700 main-menu-action ng-scope">
            Change Product 
            <i class="nbd-svg-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 6v3l4-4-4-4v3c-4.42 0-8 3.58-8 8 0 1.57.46 3.03 1.24 4.26L6.7 14.8c-.45-.83-.7-1.79-.7-2.8 0-3.31 2.69-6 6-6zm6.76 1.74L17.3 9.2c.44.84.7 1.79.7 2.8 0 3.31-2.69 6-6 6v-3l-4 4 4 4v-3c4.42 0 8-3.58 8-8 0-1.57-.46-3.03-1.24-4.26z"></path></svg>
            </i>
        </div>
    <?php
}

add_action('ndb_modal_preview_check','modalPreviewCheck');
function modalPreviewCheck($product_id){
    $product_title = get_the_title($product_id);
    $product = wc_get_product($product_id);
    if($product) {
        $price = $product->get_price();
    }
    $product_description = get_post_field('post_content', $product_id);
    $rating_count = $product->get_rating_count();
    $review_count = $product->get_review_count();
    $average      = $product->get_average_rating();
    $comments = get_comments();
    $size_guide_post_id = get_post_meta( $product_id, 'teepro_size_guide_select' );
    $size_guide_post    = get_post( $size_guide_post_id[0] );
    $size_guide_tables  = get_post_meta( $size_guide_post_id[0], 'teepro_size_guide' );
    ?>
       <div id="myModal" class="modal fade nbdesigner_modal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="popup-top">
                            <p class="tt"><?php echo $product_title; ?></p>
                        </div>
                        <button style="margin-top: 0;position: relative;top: -25px;font-size: 30px;" type="button" class="close" data-dismiss="modal" aria-hidden="true">
                            <i class="icon-nbd icon-nbd-clear tour-close js-tour-close"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="info-menu">
                            <button class="active" type-info="all">All</button>
                            <button type-info="info">Info</button>
                            <button type-info="review" class="info-menu__reviews">Reviews</button>
                            <button type-info="guide" class="info-menu__guide">Guidelines</button>
                        </div>
                        <div class="list-info">
                            <div class="ct-price info-item" type-info="info">
                                <h3><?php _e('Price','web-to-print-online-designer'); ?></h3>
                                <p>$<?php echo $price; ?></p>
                            </div>
                            <div class="ct-des info-item" type-info="info">
                                <h3><?php _e('Description','web-to-print-online-designer'); ?></h3>
                                <div><?php echo apply_filters('the_content', $product_description); ?></div>
                            </div>

                            <div class="ct-des info-item" type-info="review">
                                <h3><?php _e('Review','web-to-print-online-designer'); ?></h3>
                                <div class="info-raiting">
                                    <p>Ratings & Reviews</p>
                                    <?php 
                                        if ( $rating_count > 0 ) : ?>

                                        <div class="woocommerce-product-ratingct">
                                            <?php echo wc_get_rating_html( $average, $rating_count ); ?>
                                            <?php if ( comments_open() ) : ?>
                                                <?php //phpcs:disable ?>
                                                <p>(<?php printf( _n( '%s customer review huy', '%s customer reviews', $review_count, 'woocommerce' ), '<span class="count">' . esc_html( $review_count ) . '</span>' ); ?>)</p>
                                                <?php // phpcs:enable ?>
                                            <?php endif ?>
                                        </div>

                                        <?php endif; ?>
                                </div>
                                <div id="comments">
                                    <h2 class="woocommerce-Reviews-title">
                                        <?php
                                        $count = $product->get_review_count();
                                        if ( $count && wc_review_ratings_enabled() ) {
                                            $reviews_title = '<span>All user reviews</span>';
                                            echo apply_filters( 'woocommerce_reviews_title', $reviews_title, $count, $product );
                                        } else {
                                            esc_html_e( 'Reviews', 'woocommerce' );
                                        }
                                        ?>
                                    </h2>

                                    <?php if ( $comments ) : ?>
                                        <?php 
                                            foreach($comments as $comm) {
                                                $comment_id = $comm->comment_ID;
                                                $comment_name = $comm->comment_author;
                                                $comment_mail = $comm->comment_author_email;
                                                $comment_date = $comm->comment_date;
                                                $comment_content = $comm->comment_content;
                                                $rating_acount = get_comment_meta($comment_id, 'rating', true);
                                                ?>
                                                    <div style="display: inline-block;margin-top: 10px;">
                                                        <div class="woocommerce-product-ratingct">
                                                            <?php echo wc_get_rating_html( $rating_acount, 0 ); ?>
                                                            <?php if ( comments_open() ) : ?>
                                                                <?php //phpcs:disable ?>
                                                                <p>(<?php printf( _n( '%s customer review', '%s customer reviews', $review_count, 'woocommerce' ), '<span class="count">' . esc_html( $review_count ) . '</span>' ); ?>)</p>
                                                                <?php // phpcs:enable ?>
                                                            <?php endif ?>
                                                        </div>
                                                    </div>

                                                    <div class="info-review" style="border-bottom: 1px solid #80808045;padding-bottom: 16px;">
                                                        <p class="info-review__name">By <?php echo $comment_name; ?></p>
                                                        <b class="info-review__mail">(<?php echo $comment_mail; ?>)</b>
                                                        <p class="info-review__date"><?php echo $comment_date; ?></p>
                                                        <p class="info-review__content" style="margin-top: 10px;"><?php echo $comment_content; ?></p>
                                                    </div>
                                                <?php
                                            }
                                        ?>
                                    <?php else : ?>
                                        <p class="woocommerce-noreviews"><?php esc_html_e( 'There are no reviews yet.', 'woocommerce' ); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="ct-guide info-item" type-info="guide">
                                <h3><?php _e('Guidelines','web-to-print-online-designer'); ?></h3>
                                <?php
                                if ( !$size_guide_tables || !$size_guide_post ) return;
        
                                $hide_size_guide_table = get_post_meta( $size_guide_post->ID, 'teepro_size_guide_hide_table' );
                                $hide_size_guide_table = isset( $hide_size_guide_table[0] ) ? $hide_size_guide_table[0] : 'off';

                                ?>
                                    <div id="teepro_size_guide_wrapper" class="mfp-with-anim teepro-content-popup mfp-hide teepro-sizeguide">
                                        <h4 class="teepro-sizeguide-title"><?php echo esc_html( $size_guide_post->post_title ); ?></h4>
                                        <div class="teepro-sizeguide-content"><?php echo do_shortcode( $size_guide_post->post_content ); ?></div>
                                        <?php if ( $hide_size_guide_table == 'off' ): ?>
                                            <div class="responsive-table">
                                                <table class="teepro-sizeguide-table">
                                                    <?php foreach ( $size_guide_tables as $table ): ?>
                                                        <?php foreach ( $table as $row ): ?>
                                                            <tr>
                                                                <?php foreach ( $row as $col ): ?>
                                                                    <td><?php echo esc_html( $col ); ?></td>
                                                                <?php endforeach; ?>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    <?php endforeach; ?>
                                                </table>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
}

add_filter('nbdo_custom_title_side_pedro','nbdo_custom_title_side_pedro_ft');
function nbdo_custom_title_side_pedro_ft() {
    ?>
        <div class="show-side" style="display: flex;align-items: center;margin-right: 100px;gap: 20px;">
            <li style="height: 35px;font-weight: bold;" class="ct-side-bar menu-item item-title animated slideInDown animate600 ipad-mini-hidden" ng-repeat="(stageIndex, stage) in stages" ng-class="currentStage == $index ? 'ac' : ''" ng-click="switchStage($index, 'index')">
                <span>{{stages[stageIndex].config.name}}</span>
            </li>
        </div>
    <?php
    return '';
}